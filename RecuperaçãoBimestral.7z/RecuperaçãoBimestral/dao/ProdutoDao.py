from model.Produto import Produto

class ProdutoDao:
    def __init__(self, connection):
        self.connection = connection

    def selecionarProdutos(self) -> list:
        c = self.connection.cursor()
        sql = 'SELECT * FROM produto ORDER BY id'
        c.execute(sql)
        recset = c.fetchall()
        c.close()

        lista = []
        for item in recset:
            produto = Produto()
            produto.id = item[0]
            produto.nome = item[1]
            produto.preco = item[2]
            produto.quantidade = item[3]

            lista.append(produto)

        return lista

    def selecionarProduto(self, id) -> Produto:
        c = self.connection.cursor()
        c.execute("""select * from produto where id = {}""".format(id))
        recset = c.fetchone()
        c.close()

        produto = Produto()
        produto.id = recset[0]
        produto.nome = recset[1]
        produto.preco = recset[2]
        produto.quantidade = recset[3]

        return produto

    def inserirProduto(self, produto: Produto) -> Produto:
        c = self.connection.cursor()
        c.execute("""
            insert into produto(nome, preco, quantidade)
            values('{}', '{}', '{}') RETURNING id
        """.format(produto.nome, produto.preco, produto.quantidade))
        self.connection.commit()

    def alterarProduto(self, produto: Produto) -> Produto:        
        c = self.connection.cursor()
        c.execute("""
            update produto
            SET nome = '{}', preco = '{}', quantidade = '{}'
            WHERE id = '{}';
        """.format(produto.nome, produto.preco, produto.quantidade, produto.id))
        self.connection.commit()

   
    def excluirProduto(self, produto:Produto) -> Produto:
        c = self.connection.cursor()
        c.execute("""delete from produto where id = {}""".format(produto.id))
        self.connection.commit()




#Liedson C. Abreu e Henrique da S. Pontes