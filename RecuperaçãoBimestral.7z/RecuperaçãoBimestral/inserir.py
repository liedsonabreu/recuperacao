from tkinter import *
from dao.ProdutoDao import ProdutoDao
from config.Config import Config
from config.Database import Database

config = Config()
database = Database(config.config)
dao = ProdutoDao(database.conn)

main = Tk()
main.title("Inserir produto")
main.geometry("1000x800")

row = Frame(main)
row.pack(side=TOP, fill=X, padx=5, pady=5)

lbl = Label (row, text="Nome: ", anchor='w')
lbl.pack(side=LEFT)

txt = Entry(row)
txt.pack(side=LEFT, expand=YES, fill=X, padx=5)

lbl = Label(row, text="Preço:", anchor='w')
lbl.pack(side=LEFT)

txt2= Entry(row)
txt2.pack(side=LEFT, expand=YES, fill=X, padx=5)

lbl = Label(row, text="Quantidade:", anchor='w')
lbl.pack(side=LEFT)

txt3 = Entry(row)
txt3.pack(side=LEFT, expand=YES, fill=X, padx=5)

def inserirProduto():

    nome = txt.get()
    preco = txt2.get()
    quantidade = txt3.get()
    dao.inserirPreco1(nome, preco, quantidade)

btn = Button(main, text="Salvar", command=inserirProduto)
btn.pack(side=LEFT, padx=5, pady=5)

btn = Button(main, text="Fechar", command=main.destroy)
btn.pack(side=RIGHT, padx=5, pady=5)

main.mainloop()

